public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz fB = new FizzBuzz();
        String buzzer = fB.fizzBuzz(10);
        System.out.println(buzzer);
    }
}