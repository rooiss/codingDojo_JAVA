public class PythagoreanTest{
    public static void main(String[] args) {
        Pythagorean triangle = new Pythagorean();
        double solution = triangle.calculateHypotenuse(3, 4);
        System.out.println(solution);     
    }
}