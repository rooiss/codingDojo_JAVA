public class BatTest{
    public static void main(String[] args) {
        Bat firstbat = new Bat();
        firstbat.attackTown();
        firstbat.attackTown();
        firstbat.attackTown();
        firstbat.eatHumans();
        firstbat.eatHumans();
        firstbat.fly();
        firstbat.fly();
        firstbat.displayEnergy();
    }
}