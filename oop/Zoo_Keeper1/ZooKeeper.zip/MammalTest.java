public class MammalTest {
    public static void main(String[] args) {
        Mammal otherMammal = new Mammal();
        System.out.println(otherMammal.energyLevel);
    }
}