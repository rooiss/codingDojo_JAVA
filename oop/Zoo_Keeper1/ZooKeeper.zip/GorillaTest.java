public class GorillaTest {
    public static void main(String[] args) {
        Gorilla firstGorilla = new Gorilla();
        firstGorilla.displayEnergy();
        firstGorilla.throwSomething();
        firstGorilla.throwSomething();
        firstGorilla.throwSomething();
        firstGorilla.eatBananas();
        firstGorilla.eatBananas();
        firstGorilla.climb();
        firstGorilla.displayEnergy();
    }
}